package com.example.video4u.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.video4u.R;
import com.example.video4u.model.Video;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.Random;

public class AddVideoActivity extends AppCompatActivity {
    private int CAMERA_PERMISSION_CODE = 1;
    private int GALLERY = 2, CAMERA = 1;
    private ImageView preview;

    StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_video);
        if (!(ContextCompat.checkSelfPermission(AddVideoActivity.this,
                Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)) {
            requestCameraPermission(); // if not request permission
        }
        preview = findViewById(R.id.avatar);
        Button btn2 = findViewById(R.id.button2);
        btn2.setOnClickListener(view -> showPictureDialog());
        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(v -> {
            EditText fullname = findViewById(R.id.fullname);
            EditText console = findViewById(R.id.console);
            EditText gamename = findViewById(R.id.gamename);
            EditText year = findViewById(R.id.year);
            EditText price = findViewById(R.id.price);
            if (!isValid(fullname) || !isValid(console) || !isValid(gamename) || !isValid(year) || !isValid(price)) {
                Toast.makeText(AddVideoActivity.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            preview.setDrawingCacheEnabled(true);
            preview.buildDrawingCache();
            Bitmap bitmap = ((BitmapDrawable) preview.getDrawable()).getBitmap();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data = baos.toByteArray();
            StorageReference storageReference2 = storageRef.child(gamename.getText().toString() + ".png");
            UploadTask uploadTask = storageReference2.putBytes(data);
            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Video Video = new Video(gamename.getText().toString() + ".png", fullname.getText().toString(), console.getText().toString(), gamename.getText().toString(), year.getText().toString(), price.getText().toString());
                    Intent i = new Intent();
                    i.putExtra("Video", Video);
                    setResult(1, i);
                    finish();
                }
            });


        });
    }


    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Record photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                (dialog, which) -> {
                    switch (which) {
                        case 0:
                            chooseVideoFromGallary();
                            break;
                        case 1:
                            takeVideoFromCamera();
                            break;
                    }
                });
        pictureDialog.show();
    }

    public void chooseVideoFromGallary() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), GALLERY);

    }


    private void takeVideoFromCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, CAMERA);
        } catch (Exception e) {
            // display error state to the user

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA && resultCode == RESULT_OK) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            preview.setImageBitmap(bitmap);
        } else if (requestCode == GALLERY && resultCode == RESULT_OK) {
            Picasso.with(AddVideoActivity.this).load(data.getData()).noPlaceholder().centerCrop().fit()
                    .into(preview);
        }
    }

    private void requestCameraPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.CAMERA)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(AddVideoActivity.this,
                                    new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        }
    }

    public static boolean isValid(EditText... etText) {
        for (EditText editText : etText) {
            if (editText.getText().toString().trim().length() <= 0) {
                return false;
            }
        }
        return true;
    }


}
