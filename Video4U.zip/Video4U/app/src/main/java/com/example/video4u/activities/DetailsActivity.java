package com.example.video4u.activities;

import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import com.example.video4u.R;
import com.example.video4u.model.Video;

import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;

@RequiresApi(api = Build.VERSION_CODES.O)
public class DetailsActivity extends AppCompatActivity implements TemporalAdjuster {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Bundle b = getIntent().getExtras();
        Video Video = (Video) b.getSerializable("Video");

        ImageView avatar = findViewById(R.id.avatar);
        TextView fullname = findViewById(R.id.fullname);
        TextView console = findViewById(R.id.console);
        TextView gamename = findViewById(R.id.gamename);
        TextView year = findViewById(R.id.year);
        TextView price = findViewById(R.id.price);

//        if(Video.getUri() == null)
//            avatar.setImageResource(Video.getPhotoUrl());
//        else
//            avatar.setImageURI(Uri.parse(Video.getUri()));

        fullname.setText(Video.getFullName());
        console.setText(Video.getConsole());
        gamename.setText(Video.getGameName());
        year.setText(Video.getYear());
        price.setText(Video.getPrice());

    }

    @Override
    public Temporal adjustInto(Temporal temporal) {
        return null;
    }


}
