package com.example.video4u.utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.video4u.R;
import com.example.video4u.model.Video;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DataPersistencyHelper {


    public static void StoreData(List<Video> VideoList, Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        String json = new Gson().toJson(VideoList);
        editor.putString("VideoList", json);
        editor.apply();
    }

    public static List<Video> LoadData(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String json = sp.getString("VideoList", null);
        if (json != null) {
            Type type = new TypeToken<List<Video>>() {
            }.getType();
            return new Gson().fromJson(json, type);
        } else {
            List<Video> VideoList = new ArrayList<Video>();
            VideoList.add(new Video("video1.jpeg", "Yotam Gos", "PS4", "God Of War", "2018", "50$"));
            VideoList.add(new Video("video2.jpeg", "Dekel Vaknin", "PS4", "Spider-Man", "2017", "30$"));
            VideoList.add(new Video("video3.jpeg", "Nir Mascit", "PS4", "Guardians Of The Galaxy", "2018", "40$"));
            VideoList.add(new Video("video4.jpeg", "Bar Chen", "PS4", "Crash Bandicoot", "2018", "30$"));
            VideoList.add(new Video("video5.jpeg", "Mor Levi", "PS4", "Fortnite", "2016", "20$"));
            VideoList.add(new Video("video6.jpeg", "Or Dov", "PS4", "Marvel Avengers", "2021", "60$"));
            VideoList.add(new Video("video7.jpeg", "Eden Maor", "PS4 ", "Jumanji", "2020", "55$"));
            VideoList.add(new Video("video8.jpeg", "Yuval Coseff", "PS4", "Fast and Furious", "2017", "30$"));

            return VideoList;
        }
    }

}
