package com.example.video4u.activities.adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityOptionsCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.video4u.utilities.DataPersistencyHelper;
import com.example.video4u.activities.DetailsActivity;
import com.example.video4u.R;
import com.example.video4u.model.Video;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {
    private List<Video> VideoList;
    private Context context;
    StorageReference storageRef = FirebaseStorage.getInstance().getReference();


    public VideoAdapter(List<Video> VideoList, Context context) {
        this.VideoList = VideoList;
        this.context = context;
    }

    public class VideoViewHolder extends RecyclerView.ViewHolder {

        public CardView card;
        public ImageView avatar;
        public TextView gamename;
        public TextView price;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.card);
            avatar = itemView.findViewById(R.id.avatar);
            gamename = itemView.findViewById(R.id.gamename);
            price = itemView.findViewById(R.id.price);

        }
    }

    public void AddContact(Video Video) {
        VideoList.add(Video);
        notifyDataSetChanged();
        DataPersistencyHelper.StoreData(VideoList, context);
    }

    public void DeleteContact(int position) {
        VideoList.remove(position);
        notifyDataSetChanged();
        DataPersistencyHelper.StoreData(VideoList, context);
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_photo, parent, false);
        VideoViewHolder vh = new VideoViewHolder(v);
        return vh;
    }

    public static class SwipeToDeleteCallback extends ItemTouchHelper.SimpleCallback {
        private VideoAdapter adapter;

        public SwipeToDeleteCallback(VideoAdapter adapter) {
            super(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT);
            this.adapter = adapter;
        }

        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            int pos = viewHolder.getAdapterPosition();
            adapter.DeleteContact(pos);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        Video video = VideoList.get(position);
        StorageReference dateRef = storageRef.child("/" + video.getPhotoName());
        dateRef.getDownloadUrl().addOnSuccessListener(uri -> Picasso.with(context).load(uri).into(holder.avatar));
        holder.gamename.setText(video.getGameName());
        holder.price.setText(video.getPrice());
        {
            holder.card.setOnClickListener(v -> {
                Intent i = new Intent(v.getContext(), DetailsActivity.class);
                i.putExtra("Video", video);
                ActivityOptionsCompat options =
                        ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) v.getContext(),
                                holder.avatar,
                                "avatarTrasnition"
                        );
                v.getContext().startActivity(i, options.toBundle());
            });
        }
    }


    @Override
    public int getItemCount() {
        return VideoList.size();
    }

}
