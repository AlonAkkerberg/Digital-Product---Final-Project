package com.example.video4u.model;

import java.io.Serializable;

public class Video implements Serializable {
    private String FullName;
    private String Console;
    private String GameName;
    private String Year;
    private String Price;
    private String photoName;

    public Video(String photoName, String fullname, String console, String gamename, String year, String price) {
        this.photoName = photoName;
        FullName = fullname;
        Console = console;
        GameName = gamename;
        Year = year;
        Price = price;
    }

    public String getPhotoName() {
        return photoName;
    }

    public String getYear() {
        return Year;
    }

    public String getFullName() {
        return FullName;
    }

    public String getConsole() {
        return Console;
    }

    public String getPrice() {
        return Price;
    }

    public String getGameName() {
        return GameName;
    }


}
