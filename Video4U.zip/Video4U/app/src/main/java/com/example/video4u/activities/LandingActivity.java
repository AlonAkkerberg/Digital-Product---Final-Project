package com.example.video4u.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.video4u.R;
import com.example.video4u.activities.auth.LoginActivity;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;

public class LandingActivity extends AppCompatActivity {

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Button btn3 = findViewById(R.id.button3);
        btn3.setOnClickListener(view -> {
            Intent intent = new Intent(LandingActivity.this, MainActivity.class);
            startActivity(intent);
        });

        Button btn5 = findViewById(R.id.button5);
        btn5.setOnClickListener(v -> {
            Intent i = new Intent(LandingActivity.this, AboutUs.class);
            startActivity(i);

        });

        Button btn4 = findViewById(R.id.button4);
        btn4.setOnClickListener(v -> {
            Intent i = new Intent(LandingActivity.this, LoginActivity.class);
            startActivity(i);
            finish();
            FirebaseAuth.getInstance().signOut();

        });

    }
}
